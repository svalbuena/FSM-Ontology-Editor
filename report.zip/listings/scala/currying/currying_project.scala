def circleEquation
  (center: Point2D, radius: Double)(x: Double)
    : (Double, Double) = {
  val a = 1
  val b = -2 * center.getY
  val c = pow(x, 2) - 2 * center.getX * x + pow(center.getX, 2)
    + pow(center.getY, 2) - pow(radius, 2)

  solveQuadraticEquation(a, b, c)
}

def lineEquation(m: Double, n: Double)(x: Double): Double =
  m * x + n

val circleAt0_0Radius10 =
  circleEquation(new Point2D(0.0, 0.0), 10.0)
val circleY1 = circleAt0_0Radius10(4.0)
val circleY2 = circleAt0_0Radius10(2.0)

val line1 = lineEquation(4, -3)
val line1Y = line1(40)

val line2 = lineEquation(60, -123)
val line2Y = line1(-54)

