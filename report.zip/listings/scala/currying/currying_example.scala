//Función suma de 3 parámetros
def sum(a: Int, b: Int, c: Int): Int = {
  a + b + c
}

//Misma función suma de 3 parámetros con currying
def curriedSum(a: Int)(b: Int)(c: Int): Int = {
  a + b + c
}

//Haciendo curry de la primera lista de parámetros
val curriedSumOf1 = curriedSum(1)

//Haciendo curry de la segunda lista de parámetros
val curriedSumfOf1And2 = curriedSumOf1(2)

//Haciendo curry con dos listas de parámetros a la vez
val alternativeCurriedSumfOf1And2 = curriedSum(1)(2)

//Haciendo curry de la tercera lita de parámetros y
//obteniendo el resultado
val resultOf1plus2plus3 = curriedSumfOf1And2(3)
val alternativeResultOf1plus2plus3 =
  alternativeCurriedSumfOf1And2(3)
