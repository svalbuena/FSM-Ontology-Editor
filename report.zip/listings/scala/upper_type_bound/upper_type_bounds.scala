abstract class Figure {
 def color: Color
}

class Square extends Figure {
  override def color: Color = Color.Red
}

class Triangle extends Figure {
  override def color: Color = Color.Green
}

class Circle extends Figure {
  override def color: Color = Color.Blue
}

class FigureContainer[F <: Figure](f: F) {
  def figure: F = f
}

//Explicitando el tipo
val squareContainer = new FigureContainer[Square](new Square)

//El tipo se extrae del objeto pasado al constructor del
//contenedor de figura
val triangleContainer = new FigureContainer(new Triangle)