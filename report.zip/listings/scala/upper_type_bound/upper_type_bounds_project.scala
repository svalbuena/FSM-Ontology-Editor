class LabelVBoxSection[T <: Pane] extends VBox {
  private val titledPaneList: mutable.ListBuffer[TitledPane] =
    mutable.ListBuffer()

  private val labelButtonSection = new LabelButtonSection
  private val vBox = new VBox()

  getChildren.addAll(labelButtonSection, vBox)

  def addPane(pane: T): Unit = {
    val titledPane = new TitledPane()

    titledPaneList += titledPane
    vBox.getChildren.add(titledPane)
  }

  def removePane(pane: T): Unit = {
    val index = titledPaneList.map(_.getContent).indexOf(pane)
    if (index != -1) {
      val titledPane = titledPaneList(index)

      titledPaneList -= titledPane
      vBox.getChildren.remove(titledPane)
    }
  }
}

private val actionsSection =
  new LabelVBoxSection[ActionPropertiesBox]
def addAction(actionPropertiesBox: ActionPropertiesBox): Unit =
  actionsSection.addPane(actionPropertiesBox)
