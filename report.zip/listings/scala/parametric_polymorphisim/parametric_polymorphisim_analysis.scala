//El objeto de retorno será un elemento de la lista 'a'
def funcion1(a: List[T]): T

//El objeto de retorno es el mismo elemento recibido sin modificar
def funcion2(a: T): T
