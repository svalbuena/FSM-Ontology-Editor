//El objeto de retorno será un elemento sin modificar de la lista 'a'
def function1(a: List[T]): T

//El objeto de retorno es el mismo elemento recibido sin modificar
def function2(a: T): T
