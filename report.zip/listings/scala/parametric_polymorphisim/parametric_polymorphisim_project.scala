class ComboBoxSection[T] extends HBox {
  private val label = new Label()
  private val comboBox = new ComboBox[T]()

  getChildren.addAll(label, comboBox)

  def setLabelText(labelText: String): Unit =
    label.setText(labelText)
  
  def setItems(items: List[T]): Unit = {
    comboBox.getItems.clear()
    items.foreach(comboBox.getItems.add)
  }

  def setSelection(item: T): Unit =
    comboBox.getSelectionModel.select(item)

  def setOnSelectionChanged
    (selectionChangedHandler: T => Unit): Unit = {
      comboBox.valueProperty().addListener(_ => {
        selectionChangedHandler(comboBox.getValue)
      })
  }
}

//Hace falta especificar el tipo ya que el constructor no recibe
//ningún objeto de tipo T
val uriTypeSection = new ComboBoxSection[UriType]
uriTypeSection.setItems(List(UriType.ABSOLUTE, UriType.PROTOTYPE))

uriTypeSection.setOnSelectionChanged(newUriType => {
  //El tipo es el mismo que el tipo usado en el constructor
  val uriType: UriType = newUriType 
})
