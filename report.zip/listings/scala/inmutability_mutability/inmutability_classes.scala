//Clase Object con dos propiedades inmutables
class Object(val name: String, val price: Int)

//Creando una instancia de Objeto
val object1 = new Object("table", 10)

//Error, el atributo nombre es inmutable
object1.name = "chair" 

//Creando un nuevo objeto para editar el campo inmutable
val object2 = new Object("chair", object1.price)