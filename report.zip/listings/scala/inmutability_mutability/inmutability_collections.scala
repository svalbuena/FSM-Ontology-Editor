//Lista inmutable
val list1 = List[Int](1, 2, 3)

//Error, no se puede modificar la referencia de
//un objeto inmutable, la lista tampoco tiene ningún
//método para añadir elementos
list1 = 1 :: list1

//Creando una nueva lista a partir de la concatenación de
//un elemento con la lista
val list2 = 1 :: list1

//Creando una lista mutable
val mutableList = mutable.MutableList[Int](1, 2, 3)

//Utilizando un operador sobrecargado para añadir un elemento
//a la lista
mutableList += 1