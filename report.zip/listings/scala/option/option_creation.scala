// Crea una opción con un contenido vacío
var myIntOption: Option[Int] = None

//Crea una opción que con un contenido de valor 5
var myIntOption: Option[Int] = Some(5)

