def askForFileToOpen(): Option[String] = {
  fileChooser.setTitle("Choose the FSM file to load")
    
  val selectedFile = fileChooser.showOpenDialog(stage)
  if (selectedFile != null) {
    val filename = selectedFile.getAbsolutePath
    
    Some(filename)
  } else {
    None
  } 
}