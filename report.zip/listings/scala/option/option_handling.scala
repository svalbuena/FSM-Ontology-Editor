//Comprobando el contenido del Option con un if
if (myIntOption.isDefined) {
  val myInt = myIntOption.get
  //Tratar el entero
} else {
  //Tratar el error si es necesario
}

//Comprobando el contenido del Option con pattern matching
myIntOption match {
  case Some(myInt) => 
    //Tratar el entero
  case None =>
    //Tratar el error si es necesario
}