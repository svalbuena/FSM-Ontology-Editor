def negateFunction(f: Double => Double): Double => Double = {
  x: Double => -f(x)
}