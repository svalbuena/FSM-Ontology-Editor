def plot(f: Double => Double, fromX: Int, toX: Int): Unit = {
  for (x <- fromX to toX) {
    draw(x, f(x))
  }
}