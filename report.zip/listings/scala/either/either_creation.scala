def divide(a: Int, b: Int): Either[DivideByZeroException, Int] = {
  if (b == 0) Left(new DivideByZeroException)
  else Right(a / b)
}