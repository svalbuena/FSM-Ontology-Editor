divide(1, 2) match {
  case Left(exception) =>
    //Tratar la excepción
  case Right(result) =>
    //Tratar el resultado
}