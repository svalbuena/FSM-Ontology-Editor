def timeout_=(newTimeout: String): Either[DomainError, Int] = {
  if (!newTimeout.isEmpty
        && !newTimeout.isBlank
        && newTimeout.forall(_.isDigit)) {
            
    if (newTimeout.toInt < 0) {
      _timeout = newTimeout.toInt
      Right(timeout)
    } else {
        Left(new InvalidTimeoutError("Negative value not allowed"))
    }
  } else {
    Left(new InvalidTimeoutError("Non-Integer value not allowed"))
  }
}