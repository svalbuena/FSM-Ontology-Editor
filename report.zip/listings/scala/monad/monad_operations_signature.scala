//M, A y B son tres tipos genéricos (polimorfismo paramétrico)
def unit[A](x: A): M[A]
def flatMap[B](f: A => M[B]): M[B]

  
