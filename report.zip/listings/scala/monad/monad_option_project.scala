def loadFsm(): Unit = {
  fsmFileChooser.askForFileToOpen().flatMap(filename => {
    FsmController.loadFsm(filename) match {
    case Left(error) =>
      println(error.getMessage)
      Some(false)

    case Right(domainFsm) =>
      println("Converting")
      val fsm =
        DomainToInfrastructureConverter.convertFsm(domainFsm)

      fsmList = fsm :: fsmList
      selectFsm(fsm)

      Some(true)
    }
  })
}