val myNumbers = List(1, 2, 20)

//Versión con sintactic sugar
for (i <- myNumbers; j <- myNumbers; p <- myNumbers)
  yield (i, j, p)

//Versión sin sintactic sugar
myNumbers
  .flatMap((i: Int) =>
    myNumbers
      .flatMap((j: Int) =>
        myNumbers
          .map((p: Int) => (i, j, p))
      )
  )