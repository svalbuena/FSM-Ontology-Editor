var prototypeUriParameters: List[PrototypeUriParameter]

def getChildrenNames: List[String] =
  prototypeUriParameters.map(_.name)