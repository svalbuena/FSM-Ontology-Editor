var actions: List[Action]

def getChildrenNames: List[String] =
  actions.flatMap(a => a.name :: a.getChildrenNames)
