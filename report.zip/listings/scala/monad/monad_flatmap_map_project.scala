def getPrototypeUri(prototypeUriName: String):
  Either[DomainError, PrototypeUri] = {
  if (selectedFsmOption.isDefined) {
    val fsm = selectedFsmOption.get

    val prototypes = 
      fsm.states.flatMap(_.actions.map(_.prototypeUri))
        ::: fsm.transitions
          .flatMap(_.guards.flatMap(_.actions.map(_.prototypeUri)))
    val prototypeIndex  =
      prototypes
        .indexWhere(prototype => prototype
                                   .name.equals(prototypeUriName))

    if (prototypeIndex != -1) Right(prototypes(prototypeIndex))
    else Left(new ElementNotFoundError("PrototypeUri not found"))
  } else Left(new FsmNotSelectedError)
}