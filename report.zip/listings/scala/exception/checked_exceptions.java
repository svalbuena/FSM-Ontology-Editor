myCollection.stream().map(myItem -> {
  //El método doSomethingWithMyItem lanza una checked exception
  //Esto lanza un error de complicación
  return doSomethingWithMyItem(myItem);
});